STUDENT INFORMATION:
Name: [Your Name]
Student ID: [Your ID]
Class: [Your Class]

COMPLETED EXERCISES:
[x] Exercise 5: Search Functionality
[x] Exercise 6: Validation Enhancement
[x] Exercise 7: Pagination
[x] Bonus 1: CSV Export
[ ] Bonus 2: Sortable Columns

KNOWN ISSUES:

- [List any bugs or incomplete features]

EXTRA FEATURES:

- [List any additional features you added]

TIME SPENT: [Approximate hours]

REFERENCES USED:

- [List any websites, tutorials, or resources you used]
